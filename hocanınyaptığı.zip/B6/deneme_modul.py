# -*- coding:cp1254 -*-

liste = [1,2,3,4]
a = 42
b = 1

metin = "���i��"

def fonksiyon(inp):

	print("inp = " + str(inp) )

class sinif:

	sinif_var1 = 20.0
	sinif_var2 = "bunu yazalim"
	

	def kib(self):
		print("Kendine iyi bak")
		
	def selam(self, isim):
		print("Merhaba " + isim)

if (__name__ == "__main__"):
	
	print("Deneme")
	print("fonksiyon() - Test Ba�lang��")
	fonksiyon("input")
	print("fonksiyon() - Test Biti�")