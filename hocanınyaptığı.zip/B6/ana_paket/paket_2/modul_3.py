from .. import paket_1

def m3_f1():
	print(f"{__name__}")
	print("m3_f1")
	
	paket_1.modul_1.m1_f1()