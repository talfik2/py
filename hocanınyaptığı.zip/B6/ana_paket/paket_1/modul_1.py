

def m1_f1():
	print(f'Benim yerim {__name__} - adım m1_f1')